
import os
import time
import random
import logging
import datetime
import pytz
import requests

# Получение токена и ID чатов из переменных окружения
TOKEN = os.getenv("BOT_TOKEN")
CHAT_IDS = os.getenv("CHAT_IDS").split(",")

# Сообщения
messages = {
    "morning": [
        "Доброе утро, зая! Подключи зарядку!",
        "Зарядка — залог здоровья. Начинай день правильно!",
        "Утренняя забота: не забудь зарядить телефон!",
        "7:30 — ты зарядилась энергией?",
        "Порадуй меня — порадуй телефон зарядкой.",
        "Я всё ещё надеюсь, что телефон не разрядился.",
        "8:00 — всё ещё 13%?",
        "Любимая, зарядка — не шутка. Хах."
    ],
    "day": [
        "15:00 — всё ещё на связи?",
        "Пора проверить заряд телефона.",
        "Пока не поздно — поставь телефон на зарядку.",
        "День в разгаре, а телефон на нуле?"
    ],
    "evening": [
        "20:00 — проверка связи: сколько процентов?",
        "21:00 — поставь зарядиться перед сном.",
        "22:00 — ну и где зарядка?",
        "23:00 — ещё не поздно зарядить."
    ],
    "late": [
        "00:00 — засыпаем с зарядкой. Обязательно!",
    ],
    "special": ["бот запущен"]
}

# Временные слоты в UTC+2
schedule = {
    "morning": [5.0, 5.5, 6.0, 6.5, 7.0],       # 07:00–09:00 по Германии
    "day": [13.0],
    "evening": [18.0, 19.0, 20.0, 21.0],
    "late": [22.0],
    "special": [17.5]
}

# Часовой пояс Германии
berlin = pytz.timezone("Europe/Berlin")

def get_current_hour():
    now = datetime.datetime.now(berlin)
    return now.hour + now.minute / 60.0

def send_message(text):
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    for chat_id in CHAT_IDS:
        payload = {"chat_id": chat_id.strip(), "text": text}
        try:
            requests.post(url, data=payload)
        except Exception as e:
            logging.error(f"Error sending message to {chat_id}: {e}")

def main():
    logging.basicConfig(filename="bot_log.txt", level=logging.INFO)
    hour = get_current_hour()
    logging.info(f"{datetime.datetime.now()} - Текущее время: {hour}")

    tasks = 0
    for period, times in schedule.items():
        for t in times:
            if abs(hour - t) < 0.1:
                if period == "special":
                    send_message(messages["special"][0])
                else:
                    send_message(random.choice(messages[period]))
                tasks += 1
                break

if __name__ == "__main__":
    main()
